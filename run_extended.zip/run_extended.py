
from discord.ext import commands, tasks
import openai
import sqlite3
import os
import logging

# Initialize logging
logging.basicConfig(level=logging.INFO)

# Environment variables for API keys
DISCORD_BOT_TOKEN = os.getenv("DISCORD_BOT_TOKEN")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

# Initialize OpenAI and Discord Bot
openai.api_key = OPENAI_API_KEY
bot = commands.Bot(command_prefix='!')

# Initialize SQLite database for tickets and knowledge base
conn = sqlite3.connect('tickets.db')
c = conn.cursor()

def setup_database():
    c.execute("CREATE TABLE IF NOT EXISTS tickets (id INTEGER PRIMARY KEY AUTOINCREMENT, query TEXT, response TEXT, feedback TEXT)")
    c.execute("CREATE TABLE IF NOT EXISTS knowledge_base (id INTEGER PRIMARY KEY AUTOINCREMENT, issue TEXT, solution TEXT)")
    conn.commit()

def ask_openai(query):
    try:
        # Your OpenAI API logic here
        response = "OpenAI response"
        confidence_level = 0.9  # Simulated confidence level
    except Exception as e:
        logging.error(f"Error in OpenAI API call: {e}")
        return "An error occurred while connecting to OpenAI", 0.0
    return response, confidence_level

@bot.command()
async def ticket(ctx, *, query):
    response, confidence = ask_openai(query)
    c.execute("INSERT INTO tickets (query, response) VALUES (?, ?)", (query, response))
    conn.commit()
    ticket_id = c.lastrowid
    await ctx.send(f"Ticket created: {response} \n Your ticket ID is: {ticket_id}. \n Was this response helpful? (Yes/No)")

@bot.command()
async def feedback(ctx, ticket_id: int, feedback: str):
    c.execute("UPDATE tickets SET feedback = ? WHERE id = ?", (feedback.lower(), ticket_id))
    conn.commit()
    await ctx.send(f"Feedback for ticket ID {ticket_id} has been recorded as {feedback}.")

@tasks.loop(hours=24)
async def update_knowledge_base():
    c.execute("SELECT query, response FROM tickets WHERE feedback = 'yes'")
    for row in c.fetchall():
        query, response = row
        c.execute("INSERT INTO knowledge_base (issue, solution) VALUES (?, ?)", (query, response))
    conn.commit()

@bot.command()
@commands.has_role('Admin')
async def manual_kb_update(ctx, issue: str, solution: str):
    c.execute("INSERT INTO knowledge_base (issue, solution) VALUES (?, ?)", (issue, solution))
    conn.commit()
    await ctx.send(f"Knowledge base updated with issue: {issue} and solution: {solution}.")

@bot.event
async def on_ready():
    logging.info(f"Logged in as {bot.user}!")
    update_knowledge_base.start()

if __name__ == "__main__":
    setup_database()
    bot.run(DISCORD_BOT_TOKEN)
